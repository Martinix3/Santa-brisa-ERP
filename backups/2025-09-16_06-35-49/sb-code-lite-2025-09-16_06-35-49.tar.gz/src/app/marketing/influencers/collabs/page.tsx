import React from 'react';
import { CollabList } from '@/features/influencers/components/CollabList';

export default function Page(){
  return <CollabList />;
}
