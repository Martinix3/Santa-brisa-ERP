import React from 'react';
import { OnlinePage } from '@/features/marketing/components/ui-sb-marketing';

export default function Page(){
  return <OnlinePage/>;
}
